package dev.group.aspects;

public @interface IsAdmin {

}
