package dev.group.aspects;

public @interface Authorized {

}
