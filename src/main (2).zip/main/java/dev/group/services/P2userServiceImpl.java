package dev.group.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import dev.group.beans.P2user;
import dev.group.repositories.P2userRepository;

@Service
public class P2userServiceImpl implements P2userService {

	@Autowired
	P2userRepository ur;

	@Override
	public P2user createP2user(P2user user) {
		return ur.save(user);
	}

	@Override
	public P2user getUserById(int userId) {
		System.out.println("userId is:" + userId);
		int id = userId;
		return ur.findById(id).get();
	}

	@Override
	public List<P2user> allP2users() {
		return (List<P2user>) ur.findAll();
	}

	@Override
	public P2user getP2usersByUsernameAndPword(String username, String pword) {
		return ur.findByUsernameAndPword(username,pword);
	}

	@Override
	public P2user updateP2user(P2user change) {
		return ur.save(change);
	}

	@Override
	public boolean deleteP2user(P2user user) {
		try{
			ur.delete(user);
			return true;
		}catch(IllegalArgumentException e) {
			e.printStackTrace();
			return false;
		}
	}

	
	//not being used at this point
	@Override
	public List<P2user> getP2usersByEmailAndPassword(String email, String password) {
		// TODO Auto-generated method stub
		return null;
	}

}
